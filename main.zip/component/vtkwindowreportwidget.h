#ifndef VTKWINDOWREPORTWIDGET_H
#define VTKWINDOWREPORTWIDGET_H

#include <QWidget>

class VtkWindowReportWidget : public QWidget
{
    Q_OBJECT
public:
    explicit VtkWindowReportWidget(QWidget *parent = nullptr);

signals:
};

#endif // VTKWINDOWREPORTWIDGET_H
